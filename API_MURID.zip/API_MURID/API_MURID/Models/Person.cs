﻿namespace API_MURID.Models
{
    public class SISWA
    {
        public int id_person { get; set; }
        public string nama { get; set; }
        public string alamat { get; set; }
        public string email { get; set; }
    }
}
