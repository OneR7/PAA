﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;

namespace Percobaan1.Models
{
    public class Person
    {
        public int id_person { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string email { get; set; }
    }

    public class Filter
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Person API", Version = "v1" });
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Person API V1");
                    c.RoutePrefix = string.Empty;
                });
            }

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }

    [ApiController]
    [Route("api/[controller]")]
    public class PersonController : ControllerBase
    {
        private readonly List<Person> persons;

        public PersonController()
        {
            PersonContext context = new PersonContext();
            persons = context.ListPerson();
        }

        [HttpGet("{id_person}")]
        public IActionResult Get(int id_person)
        {
            var person = persons.Find(p => p.id_person == id_person);
            if (person == null)
            {
                return NotFound();
            }
            return Ok(person);
        }
    }

}
